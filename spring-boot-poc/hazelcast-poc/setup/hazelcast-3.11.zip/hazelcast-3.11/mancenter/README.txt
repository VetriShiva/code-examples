# Where has Management Center gone?

The Management Center now follows its own release cycle. The Hazelcast
IMDG distributions will no longer contain the Management Center binaries.

## Where can I download the Management Center from?

The Management Center now has it's own section on Hazelcast download page.

https://hazelcast.org/download/